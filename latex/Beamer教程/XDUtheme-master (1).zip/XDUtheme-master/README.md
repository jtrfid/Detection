# 西电研究生毕业答辩Beamer模板
---

## 主题介绍

本模板为西安电子科技大学主题的Beamer模版。本模版以[XDUstyle-Beamer-Theme](https://github.com/StickCui/XDUstyle-Beamer-Theme)为基础进行修改，并参考了[THUBeamer](https://github.com/tl3shi/THUBeamer)。在此感谢StickCui和tl3shi。




### 文件（夹）介绍

	主题主要文件：
	|--------- beamerthemeXDUstyle.sty % 主题文件
	|--------- beamerouterthemeXDUstyle.sty % 外部主题
	|--------- beamerinnerthemeXDUstyle.sty % 内部主题
	|--------- beamercolorthemeXDUstyle.sty % 配色主题
	|--------- beamerfontthemeXDUstyle.sty  % 字体主题
    
	示例文件：
	|------- Demo.tex
	|------- Demo.pdf

	文件夹：
	|----- XDUtheme % 主题用到的矢量图文件夹
	|----- figures % 图文件文件夹，用于存放自己用到的图片，避免与主题的混淆。
    |----- sections % 子章节文件夹


	
	